# Quick Test Guide - Job Tracker Extension

## Install & Test (15 minutes)

### 1. Extract the Extension
```bash
# Download job-tracker-extension-v1.1.0-chrome.zip
# Unzip to a folder you'll remember
```

### 2. Load in Chrome
1. Open Chrome
2. Go to: `chrome://extensions/`
3. Enable "Developer mode" (toggle top-right)
4. Click "Load unpacked"
5. Select the unzipped folder
6. Extension appears in toolbar!

### 3. Test Core Features

**First Launch:**
- Click extension icon
- Set weekly goal (try 10)
- Click "Get Started"

**Save a Job:**
- Go to any job posting (LinkedIn, Indeed, etc.)
- Click extension icon
- Check if details auto-filled
- Edit anything wrong
- Click "Save Application"
- Look for green checkmark

**Check Dashboard:**
- Click extension icon
- Click "View Dashboard"
- See your saved job?
- Stats showing 1 application?

**Test Editing:**
- Click on the job title in the table
- Type new text
- Press Enter
- Did it save?

**Test Status:**
- Use dropdown to change status
- Try: Applied → Interviewing
- Did it update?

**Test Delete:**
- Click trash icon
- Confirm deletion
- Job removed?

### 4. Test Notifications (Optional)
- Click "Settings"
- Make sure notifications are ON
- Wait for daily reminder (6 PM)
- Or test by changing system time

## If Something Breaks

**Extension won't load:**
- Make sure you selected the right folder (contains manifest.json)
- Check Developer mode is ON
- Try refreshing the extensions page

**Auto-fill not working:**
- Normal! Not all sites supported
- Just type the details manually
- Common sites (LinkedIn, Indeed) work well

**Data not saving:**
- Check browser console (F12) for errors
- Try closing and reopening popup
- Check if storage permissions are granted

## Ready to Launch?

If everything works:
✅ Extension installs correctly
✅ Can save jobs
✅ Can edit inline
✅ Can change status
✅ Dashboard shows stats
✅ Settings page works

**YOU'RE READY TO GO PUBLIC!**

Next: Upload to Chrome Web Store

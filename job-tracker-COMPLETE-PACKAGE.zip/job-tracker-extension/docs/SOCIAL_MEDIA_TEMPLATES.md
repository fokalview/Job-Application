# Social Media Post Templates

Copy-paste these templates for your launch. Customize with your own voice!

---

## 📱 Reddit Posts

### r/jobs

**Title:** I built a free Chrome extension to track job applications (with accountability features)

**Body:**
```
After losing track of 50+ applications this year, I built something to help:

**Job Application Tracker** - Free Chrome/Edge extension

What it does:
• Save jobs from any site with one click (LinkedIn, Indeed, Handshake, etc.)
• Set weekly application goals and track progress
• Get daily reminders when behind on your goal
• Share progress with accountability partners
• Generate professional email reports

I made this because:
1. Spreadsheets are tedious
2. Other tools cost $30/month
3. I needed accountability, not just organization

It's 100% free. No premium tiers. No tracking. All data stored locally.

[Link to extension]

Open to feedback from fellow job hunters!
```

---

### r/college

**Title:** Made a free tool to track job apps and stay accountable during the search

**Body:**
```
Graduating soon and the job search is overwhelming. I built a Chrome extension 
to help stay organized:

**Features:**
✅ One-click save from Handshake/LinkedIn/Indeed
✅ Set weekly application goals  
✅ Share progress with friends/roommates for accountability
✅ Get reminders when you're slacking
✅ Weekly email summaries

**Why I built it:**
- Spreadsheets suck
- Needed my roommate to keep me accountable
- Other tools are expensive or bloated

**It's free and always will be.**

Perfect for anyone applying to 10+ jobs per week.

[Link]

Would love feedback from other students!
```

---

### r/cscareerquestions

**Title:** [Tool] Free Chrome extension for tracking applications with goal-setting

**Body:**
```
Built a lightweight Chrome extension for the job search grind.

**Stack:** Vanilla JS, no frameworks, <100KB

**Features:**
- Auto-extract job details from pages
- Weekly goal tracking with notifications
- Accountability partner system
- Local storage only (privacy-first)
- Works on 50+ job boards

**Why another job tracker?**
Everyone focuses on automation. Nobody focuses on accountability. 
This fills that gap.

**Open source:** [GitHub link]
**Install:** [Chrome Store link]

Feedback welcome - especially on the tech stack decisions!
```

---

## 🔗 LinkedIn Post

```
After 6 months of job searching, here's what I learned:

Tracking applications in spreadsheets made me MORE stressed, not less.

So I built a better solution ⬇️

Job Application Tracker - a free Chrome extension that helps you:

✅ Track every application in one place
✅ Set weekly goals and actually hit them  
✅ Stay accountable with progress sharing
✅ Get reminders when you're behind

**Why I built this:**

Most job trackers focus on automation and AI. That's fine, but what I 
really needed was ACCOUNTABILITY.

Someone to check in on my progress. A system to keep me consistent. 
A way to measure if I'm actually putting in the work.

This extension does that.

**It's completely free.** No premium tiers, no paywalls, no BS.

I built it to solve my own problem. Sharing in case it helps you too.

Link: [Chrome Web Store / GitHub]

---

If you're job hunting right now - you've got this. Stay consistent. 
Track your progress. And don't give up.

#JobSearch #CareerAdvice #OpenSource #ChromeExtension #Accountability
```

---

## 🐦 Twitter/X Thread

```
I just shipped a free Chrome extension for job seekers 🧵

The problem: 
You apply to 50+ jobs and lose track of everything. 

Spreadsheets are tedious. 
Other tools are $30/month.
You have no accountability.

The solution: 
A lightweight extension that helps you track, set goals, and stay accountable.

Features:
• One-click save from any job board
• Weekly goal tracking
• Accountability partners  
• Smart reminders
• Email reports

Why I built this:

I was applying to jobs last semester and drowning in applications.

Realized I didn't need MORE features. I needed ACCOUNTABILITY.

So I built exactly that.

Tech stack:
• Vanilla JavaScript (no frameworks)
• <100KB total
• 100% local storage
• Zero external dependencies

Open source: [GitHub link]
Install: [Chrome Store link]

It's free. Forever. No premium tier.

If you're job hunting - RT to help someone who needs this 👇

Also: feedback welcome! What features would make this better?

[End thread]
```

---

## 📧 Email to Career Centers

```
Subject: Free tool to help your students track job applications

Hi [Name/Career Center],

I noticed [University] uses Handshake to support students in their job search.

I recently built a free Chrome extension that complements Handshake perfectly 
- it helps students stay organized and accountable while applying.

**Job Application Tracker**

Features:
• Save jobs from any site (including Handshake) with one click
• Track weekly application goals with visual progress
• Share progress with career coaches/advisors
• Generate professional email reports
• 100% free and privacy-focused (local storage only)

**Why I built it:**

As a recent [grad/student], I noticed how overwhelming the application 
process can be. Students apply to dozens of jobs but lose track quickly.

This tool helps them stay consistent and accountable - which is often 
more important than fancy features.

**Would you be interested in:**
• Featuring this in your next student newsletter?
• Mentioning it in job search workshops?
• Testing it with a small group of students?

I'm happy to provide materials, screenshots, or demo it for your team.

The extension is open source and will always be free for students.

GitHub: [link]
Chrome Store: [link when live]

Best regards,
[Your Name]
[Your LinkedIn/Contact]

P.S. - I'm especially excited about the accountability partner feature. 
Students can add their career advisors to receive weekly progress updates!
```

---

## 📺 TikTok/Instagram Caption Ideas

### Video 1: "The Problem"
```
POV: You've applied to 50 jobs and can't remember which ones 😭

*shows messy spreadsheet*
*shows 100 browser tabs*
*shows missed follow-ups*

There's a better way ⬇️

#jobsearch #careertok #productivity #collegegrad
```

### Video 2: "The Solution"
```
How I actually stay organized during my job search:

1️⃣ See a job I like
2️⃣ Click extension (auto-fills everything)
3️⃣ Submit
4️⃣ Track progress on dashboard

Set weekly goals. Get reminders. Stay accountable.

Free Chrome extension - link in bio

#jobsearchtips #careeradvice #productivityhacks
```

### Video 3: "Weekly Goals"
```
Why I set weekly job application goals:

Applying to jobs is a numbers game.

10 apps/week = 40/month = 480/year

You literally can't fail if you stay consistent.

This extension keeps me accountable 📊

#jobsearch #goalsetting #accountability
```

---

## 💬 Discord/Slack Message (for communities)

```
Hey everyone! 👋

I just launched a free Chrome extension for job hunting and would love feedback.

**What it does:**
Helps you track applications, set weekly goals, and stay accountable

**Why it's different:**
Most job trackers focus on automation. This focuses on keeping you motivated 
and consistent during the grind.

**Perfect for:**
Anyone applying to 5+ jobs per week who needs accountability

It's free and open source: [GitHub link]

Would appreciate any feedback or feature ideas! 🙏
```

---

## 📝 Hacker News Post

**Title:** Show HN: Accountability-focused job application tracker (Chrome extension)

**Body:**
```
I built a Chrome extension to help job seekers stay organized and accountable.

Most job tracking tools focus on automation and AI features. I wanted something 
simpler: help people stay consistent and hit their weekly application goals.

Features:
- One-click save from any job board
- Weekly goal tracking with visual progress
- Accountability partner system (share progress with friends/mentors)  
- Smart notifications when behind on goals
- Privacy-first (100% local storage)

Tech stack: Vanilla JS, no frameworks, <100KB total

Why vanilla JS? Wanted to keep it lightweight and avoid the framework bloat. 
The entire extension is smaller than a single React bundle.

Open source: [GitHub link]
Live: [Chrome Web Store link]

Feedback welcome - especially on the minimalist approach!
```

---

## 🎥 Product Hunt Description

**Tagline:** Track job applications and stay accountable with weekly goals

**Description:**
```
Job Application Tracker helps you stay organized and motivated during 
your job search.

🎯 Set weekly application goals
📊 Track your progress visually
🤝 Add accountability partners
📧 Generate email reports to share
🔔 Get smart reminders

Unlike other job trackers that focus on automation, we focus on what 
actually matters: staying consistent.

Perfect for:
• College students on Handshake
• Recent grads applying everywhere  
• Anyone who needs accountability

100% free. No ads. No tracking. Privacy-first design.

Built by a job seeker, for job seekers.
```

---

## 📊 Use These Stats in Your Posts

- "After 100+ applications, I finally built a better way to track them all"
- "Track 50+ job applications without losing your mind"
- "Set weekly goals and actually hit them"
- "Under 100KB - 50x smaller than competitors"
- "Works on 50+ job boards (LinkedIn, Indeed, Handshake, etc.)"
- "100% local storage - no servers, no tracking"
- "Completely free - no premium tiers or paywalls"

---

## 🎨 Hashtag Combinations

**Job Search:**
#jobsearch #jobhunt #jobhunting #jobsearchtips #careeradvice #careerdevelopment

**Students:**
#collegegrad #classof2026 #internship #handshake #careercenter #jobfair

**Productivity:**
#productivity #goalsetting #accountability #organization #timemanagement

**Tech:**
#chromeextension #opensource #sideproject #indiehacker #buildinpublic

---

**Pro Tips:**

1. **Be authentic** - Share YOUR story about why you built this
2. **Engage quickly** - Reply to comments within the first hour
3. **Don't spam** - Space out posts across different platforms
4. **Use visuals** - Screenshots and GIFs perform 10x better
5. **Track what works** - Note which posts get the most engagement

**Good luck with your launch!** 🚀

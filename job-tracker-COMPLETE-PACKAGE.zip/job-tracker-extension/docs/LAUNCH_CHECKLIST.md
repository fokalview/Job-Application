# 🚀 Launch Checklist - Job Application Tracker Extension

Use this checklist to go from code to users!

---

## Phase 1: Pre-Launch Setup (Day 1-2)

### ☐ GitHub Setup
- [ ] Create GitHub account (if you don't have one)
- [ ] Create new repository: `job-tracker-extension`
- [ ] Upload using the git bundle:
  ```bash
  git clone job-tracker-extension.bundle job-tracker-extension
  cd job-tracker-extension
  git remote add origin https://github.com/YOUR_USERNAME/job-tracker-extension.git
  git push -u origin master
  git push --tags
  ```
- [ ] Add repository description: "Lightweight Chrome/Edge extension for job seekers to track applications, set goals, and stay accountable"
- [ ] Add topics: `job-search`, `chrome-extension`, `edge-extension`, `accountability`, `goal-tracking`, `handshake`, `career`
- [ ] Enable Issues and Discussions

### ☐ Take Screenshots
- [ ] Install the extension locally
- [ ] Add 5-10 sample applications with realistic data
- [ ] Take screenshots (1280x800):
  - Popup with auto-filled job
  - Dashboard overview with stats
  - Applications table
  - Accountability partners screen
  - Weekly progress chart
- [ ] Save to `screenshots/` folder
- [ ] Commit and push screenshots

### ☐ Create Donation Page (Optional)
- [ ] Sign up for Ko-fi: https://ko-fi.com
- [ ] Set up page with your story
- [ ] Add donation button to Settings page in extension
- [ ] Test donation flow

---

## Phase 2: Chrome Web Store Submission (Day 2-3)

### ☐ Developer Account Setup
- [ ] Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole)
- [ ] Pay $5 one-time developer fee
- [ ] Verify email address

### ☐ Prepare Store Listing
**Store Listing Details:**

**Name:** Job Application Tracker & Goals

**Summary (132 chars max):**
"Track job applications, set weekly goals, and stay accountable. Lightweight & privacy-focused for college students and grads."

**Description:**
```
Stop losing track of your job applications! 

Job Application Tracker helps you stay organized and motivated during your job search with:

✅ ONE-CLICK SAVE - Save jobs from any board (LinkedIn, Indeed, Handshake, etc.)
📊 WEEKLY GOALS - Set targets and track your progress visually  
🤝 ACCOUNTABILITY - Share progress with friends, mentors, or career coaches
🔔 SMART REMINDERS - Daily nudges when you're behind on your goal
📧 EMAIL REPORTS - Professional weekly summaries to share
📈 ANALYTICS - See your stats, weeks on track, and averages

PERFECT FOR:
• College students job hunting
• Recent grads applying everywhere
• Anyone drowning in applications
• People who need accountability

FEATURES:
• Auto-detect job details from web pages
• Edit all fields inline with one click
• Track application status (Applied → Interviewing → Offer)
• Weekly goal celebrations when you hit your target
• Export/import your data anytime
• 100% local storage - no servers, no tracking
• Works on 50+ job boards

LIGHTWEIGHT & FAST:
• Under 100KB (50x smaller than competitors)
• No frameworks or bloat
• Privacy-first design

WHY THIS EXTENSION?
Unlike other job trackers that focus on automation, we focus on what matters: 
staying motivated and accountable during the grind.

FREE FOREVER. NO ADS. NO TRACKING.

Questions? GitHub: github.com/YOUR_USERNAME/job-tracker-extension
```

**Category:** Productivity

**Language:** English

**Screenshots:** Upload your 5 screenshots

**Promotional Tile (440x280):** Optional but recommended

**Pricing:** Free

**Permissions Justification:**
- Storage: "Save application data locally"
- Active Tab: "Auto-detect job details from current page"
- Scripting: "Extract job information from web pages"
- Notifications: "Send goal reminders and achievement celebrations"
- Alarms: "Schedule daily and weekly notifications"

### ☐ Submit for Review
- [ ] Upload `job-tracker-extension-v1.1.0-chrome.zip`
- [ ] Fill in all required fields
- [ ] Submit for review
- [ ] Wait 1-3 business days

---

## Phase 3: Microsoft Edge Add-ons Submission (Day 2-3)

### ☐ Developer Account Setup
- [ ] Go to [Edge Partner Center](https://partner.microsoft.com/dashboard/microsoftedge)
- [ ] Register (FREE - no fee!)
- [ ] Complete developer profile

### ☐ Prepare Store Listing
Use the **same description** as Chrome, but update:

**Summary:**
"Track job applications, set weekly goals, stay accountable. Perfect for Handshake users and college students!"

### ☐ Submit for Review
- [ ] Upload `job-tracker-extension-v1.1.0-edge.zip`
- [ ] Fill in all required fields
- [ ] Submit for review
- [ ] Wait 1-3 business days

---

## Phase 4: Reddit Launch (Day 1 - Do This First!)

### ☐ Prepare Reddit Post

**Title:**
"I built a free Chrome extension to track job apps and stay accountable (perfect for Handshake users)"

**Body:**
```
After applying to 100+ jobs this semester and losing track, I built a tool to help:

**Job Application Tracker** - Free Chrome/Edge extension

What it does:
• One-click save from ANY job board (Handshake, LinkedIn, Indeed, etc.)
• Set weekly application goals
• Get reminders when you're behind
• Share progress with accountability partners
• Generate email reports for career coaches

I built this because spreadsheets suck and other tools are $30/month with features I don't need.

This is 100% free. No ads, no tracking, all local storage.

[Link to Chrome Web Store / GitHub]

Fellow job hunters - would love your feedback!
```

### ☐ Post to These Subreddits (Space them out!)
- [ ] r/jobs (700k+ members)
- [ ] r/careerguidance (300k+ members)
- [ ] r/internships (100k+ members)
- [ ] r/college (500k+ members)
- [ ] r/cscareerquestions (900k+ members)
- [ ] r/EngineeringStudents (200k+ members)
- [ ] r/StudentLoans (60k+ members)
- [ ] University-specific subs (r/berkeley, r/UCLA, etc.)

**Tip:** Post to 2-3 per day to avoid spam flags

---

## Phase 5: Email Career Centers (Day 3-5)

### ☐ Create Email Template

**Subject:** Free tool to help your students track job applications

**Body:**
```
Hi [Career Center Name],

I noticed [University] uses Handshake to help students with their job search. 

I recently built a free Chrome extension that complements Handshake perfectly - 
it helps students stay organized and accountable while applying to jobs.

Features:
• Save jobs from any site (including Handshake) with one click
• Track weekly application goals
• Share progress with career coaches/advisors
• Generate weekly email reports

It's lightweight, privacy-focused (local storage only), and completely free.

Would you be open to sharing this with students in your next newsletter or 
workshop? I'm happy to provide materials or demo it for your team.

GitHub: [link]
Chrome Store: [link when live]

Best,
[Your Name]
```

### ☐ Target These Universities First
- [ ] Your own university
- [ ] Top 10 schools by size (ASU, UCF, Texas A&M, etc.)
- [ ] Schools with active CS programs
- [ ] Community colleges (often overlooked but huge user base!)

**Find contacts:**
- Google: "[University name] career services contact"
- LinkedIn: Search for Career Advisors
- University website: Career center email

**Goal:** Email 5-10 per day

---

## Phase 6: Social Media (Day 3-7)

### ☐ LinkedIn Post

**Post:**
```
After 100+ job applications, I realized tracking them in spreadsheets was 
making me more stressed, not less.

So I built something better: a free Chrome extension that helps you:
✅ Track every application in one place
✅ Set weekly goals and actually hit them
✅ Share progress with accountability partners

It's designed for the job search grind - no bloat, just what you need to 
stay organized and motivated.

Completely free. No premium tiers, no paywalls.

Check it out: [link]

#JobSearch #CareerAdvice #OpenSource
```

### ☐ TikTok/Instagram (If comfortable with video)

**Video Ideas:**
1. "POV: You've applied to 50 jobs and forgot where" → Show the chaos → Show the extension
2. "How I track job applications without going insane"
3. "Setting weekly job goals actually works (here's how)"

**Hashtags:** #jobsearch #collegegrad #careeradvice #productivity #handshake

### ☐ Twitter/X

**Thread:**
```
I just shipped a free Chrome extension for job seekers 🧵

The problem: You apply to 50+ jobs and lose track of everything

The solution: Track it all in one place, set weekly goals, stay accountable

Built this because I was drowning in applications last semester.

Features: [list]

Link: [link]

RT if you're job hunting! 👇
```

---

## Phase 7: Product Hunt Launch (Week 2)

### ☐ Prepare Launch
- [ ] Create Product Hunt account
- [ ] Schedule launch for Tuesday-Thursday (best days)
- [ ] Prepare tagline: "Accountability-focused job application tracker for students"
- [ ] Upload screenshots and demo

### ☐ Launch Day
- [ ] Post at 12:01 AM PST
- [ ] Ask friends to upvote (first 4 hours matter most)
- [ ] Respond to all comments
- [ ] Share on your social media

---

## Phase 8: Iterate Based on Feedback (Ongoing)

### ☐ Monitor Channels
- [ ] GitHub Issues
- [ ] Chrome Web Store reviews
- [ ] Edge Add-ons reviews
- [ ] Reddit comments
- [ ] Email responses

### ☐ Common Feature Requests to Expect
- Notes field per application
- Interview date tracking
- Cover letter storage
- Resume version tracking
- Mobile app

**Don't add everything!** Stay focused on the core: goals and accountability.

---

## Success Metrics

### Week 1 Goals:
- [ ] 50 installs
- [ ] 5 GitHub stars
- [ ] 3 career centers interested

### Month 1 Goals:
- [ ] 500 installs
- [ ] 50 GitHub stars
- [ ] 10 career centers using it
- [ ] Listed on Chrome Web Store

### Month 3 Goals:
- [ ] 2,000 installs
- [ ] 100 GitHub stars
- [ ] First donation (if Ko-fi enabled)
- [ ] Consider freemium features

---

## 🎉 You're Ready to Launch!

**Priority Order:**
1. **Day 1:** Post to Reddit (2-3 subs)
2. **Day 2:** Submit to Chrome Web Store
3. **Day 2:** Submit to Edge Add-ons
4. **Day 3:** Email 5 career centers
5. **Day 4:** Post on LinkedIn
6. **Week 2:** Product Hunt launch

**Remember:**
- Be genuine in your posts (you built this to solve YOUR problem)
- Respond to every comment and email
- Iterate based on feedback
- Don't spam - space out your posts
- Celebrate small wins!

**Good luck! 🚀**

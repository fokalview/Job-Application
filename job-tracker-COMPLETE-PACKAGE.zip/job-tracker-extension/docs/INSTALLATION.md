# Installation Guide

## Quick Install (Chrome Web Store)

**Coming Soon!** Once published, you'll be able to install with one click from the Chrome Web Store.

---

## Manual Installation (For Testing & Development)

### Prerequisites
- Google Chrome 88+ or Edge 88+ (Chromium-based)
- 5 minutes of your time

### Step-by-Step Installation

#### 1. Download the Extension

**Option A: Download ZIP**
- Click the green "Code" button on GitHub
- Select "Download ZIP"
- Unzip the file to a location you'll remember

**Option B: Clone with Git**
```bash
git clone https://github.com/yourusername/job-tracker-extension.git
cd job-tracker-extension
```

#### 2. Open Chrome Extensions Page

- Open Google Chrome
- Go to `chrome://extensions/`
- Or click: Menu (⋮) → Extensions → Manage Extensions

#### 3. Enable Developer Mode

- Look for "Developer mode" toggle in the top-right corner
- Click to enable it

#### 4. Load the Extension

- Click "Load unpacked" button (appears after enabling Developer mode)
- Navigate to the `job-tracker-extension` folder
- Select the folder and click "Open"

#### 5. Pin the Extension

- Click the puzzle icon (🧩) in your Chrome toolbar
- Find "Job Application Tracker & Goals"
- Click the pin icon (📌) to keep it visible

#### 6. First-Time Setup

- Click the extension icon in your toolbar
- Set your weekly application goal (e.g., 10)
- Click "Get Started"

**You're ready to go!** 🎉

---

## Updating the Extension

When a new version is released:

1. Download/pull the latest code
2. Go to `chrome://extensions/`
3. Click the refresh icon (🔄) on the extension card

**Or** remove and reinstall following the steps above.

---

## Uninstalling

To remove the extension:

1. Go to `chrome://extensions/`
2. Find "Job Application Tracker & Goals"
3. Click "Remove"
4. Confirm deletion

**Note:** This will delete all your saved applications and data.

---

## Troubleshooting

### Extension doesn't load
- Make sure you selected the correct folder (should contain `manifest.json`)
- Check that Developer mode is enabled
- Try refreshing the extensions page

### Auto-fill not working
- Some job sites aren't supported yet
- Manually enter the details if needed
- Common sites (LinkedIn, Indeed) work well

### Notifications not showing
- Check Chrome notification permissions
- Make sure notifications are enabled in Settings
- Restart Chrome if needed

### Data not saving
- Check browser storage permissions
- Try exporting and re-importing your data
- Clear extension storage and restart

### Other Issues
- Open an issue on GitHub
- Include your browser version and OS
- Provide steps to reproduce

---

## Browser Compatibility

✅ **Supported:**
- Chrome 88+
- Edge 88+ (Chromium-based)
- Brave
- Vivaldi
- Opera

❌ **Not Supported:**
- Firefox (different manifest version)
- Safari (different extension system)

---

## Next Steps

After installation:

1. **Save Your First Job** - Navigate to any job posting and click the extension icon
2. **Set Up Accountability** - Add a friend or mentor to share progress
3. **Check Your Dashboard** - View your stats and weekly progress
4. **Customize Settings** - Adjust goals and notification preferences

---

**Need help?** Open an issue on GitHub or check the [README](README.md) for more info!

# Microsoft Edge Installation Guide

## ✅ Great News!

This extension works **identically** on Microsoft Edge! Since Edge uses the same Chromium engine as Chrome, you can install it with zero modifications.

---

## Quick Install (Edge Add-ons Store)

**Coming Soon!** Once published, you'll be able to install with one click from the Microsoft Edge Add-ons store.

---

## Manual Installation (For Testing)

### Step-by-Step Installation

#### 1. Download the Extension

Download from GitHub:
- Click the green "Code" button
- Select "Download ZIP"
- Unzip to a location you'll remember

#### 2. Open Edge Extensions Page

- Open Microsoft Edge
- Go to `edge://extensions/`
- Or click: Menu (⋯) → Extensions → Manage Extensions

#### 3. Enable Developer Mode

- Look for "Developer mode" toggle in the left sidebar
- Click to enable it

#### 4. Load the Extension

- Click "Load unpacked" button
- Navigate to the `job-tracker-extension` folder
- Select the folder and click "Select Folder"

#### 5. Pin the Extension

- Click the extensions icon (puzzle piece 🧩) in your Edge toolbar
- Find "Job Application Tracker & Goals"
- Click the eye icon (👁️) to pin it to the toolbar

#### 6. First-Time Setup

- Click the extension icon in your toolbar
- Set your weekly application goal (e.g., 10)
- Click "Get Started"

**You're ready to track jobs on Edge!** 🎉

---

## Features on Edge

All features work exactly the same:
- ✅ One-click save from job boards
- ✅ Auto-detection of job details
- ✅ Weekly goal tracking
- ✅ Accountability partners
- ✅ Email reports
- ✅ Smart notifications
- ✅ Full dashboard
- ✅ Inline editing
- ✅ Data export/import

---

## Edge-Specific Features

**Bonus:** If you use Edge's Collections feature, you can save jobs both ways:
1. **Extension** - For goal tracking and accountability
2. **Collections** - For organizing research

They work great together!

---

## Syncing Across Devices

If you sign in to Edge with your Microsoft account:
- Your extension data stays on each device (local storage)
- To sync: Use Export/Import feature in Settings
- Export from Device A → Import to Device B

**Note:** Cross-device sync is planned for a future update!

---

## Publishing to Edge Add-ons Store

This extension will be published to the Microsoft Edge Add-ons store soon.

**For developers:** The exact same files work! No changes needed to the manifest or code.

---

## Troubleshooting

### Extension doesn't load
- Make sure you selected the correct folder (contains `manifest.json`)
- Check that Developer mode is enabled
- Try refreshing the extensions page

### Notifications not working
- Check Edge notification permissions
- Settings → Cookies and site permissions → Notifications
- Make sure Edge is allowed to show notifications

### Other Issues
Same as Chrome - see [INSTALLATION.md](INSTALLATION.md) for detailed troubleshooting.

---

## Edge vs Chrome

**What's different?**
- Nothing! The extension is identical.

**Which should I use?**
- Whichever browser you prefer
- You can install on both if you use multiple browsers

---

## Next Steps

1. Start tracking your first job application
2. Set up accountability partners
3. Customize your weekly goal
4. Explore the dashboard

---

**Questions?** Open an issue on GitHub!

**Made with ❤️ for Edge users too!**

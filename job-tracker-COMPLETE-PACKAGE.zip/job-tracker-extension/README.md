# Job Application Tracker & Goals - Chrome Extension

A professional job tracking extension focused on accountability and goal-setting.

## Features

✅ **One-Click Save** - Save job applications from any website with auto-detection  
📊 **Weekly Goals** - Set and track your weekly application targets  
🎯 **Progress Tracking** - Visual dashboards showing your job search progress  
📧 **Accountability** - Add partners and share weekly progress reports  
🔔 **Smart Reminders** - Daily and weekly notifications to keep you on track  
📈 **Analytics** - Track your stats, weeks on track, and average applications  
💾 **Export Reports** - Generate email-ready weekly summaries  

## Installation

### From Source (For Testing)

1. **Download the extension**
   - Download or clone this repository
   - Unzip if necessary

2. **Open Chrome Extensions**
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top-right)

3. **Load the extension**
   - Click "Load unpacked"
   - Select the `job-tracker-extension` folder
   - The extension icon should appear in your toolbar

4. **Pin the extension**
   - Click the puzzle icon in Chrome toolbar
   - Find "Job Application Tracker & Goals"
   - Click the pin icon to keep it visible

## How to Use

### First Time Setup

1. Click the extension icon
2. Set your weekly application goal
3. Click "Get Started"

### Saving Applications

1. Navigate to any job posting (LinkedIn, Indeed, etc.)
2. Click the extension icon
3. Review auto-filled details (edit if needed)
4. Click "Save Application"
5. Done! Your weekly progress updates automatically

### Viewing Your Dashboard

1. Click the extension icon
2. Click "View Dashboard"
3. See your stats, progress, and all applications

### Adding Accountability Partners

1. Open Dashboard → Accountability tab
2. Click "Add Accountability Partner"
3. Enter their name and email
4. Choose update frequency (daily/weekly/biweekly)
5. Click "Add Partner"

### Generating Reports

**Email Report:**
1. Dashboard → Accountability tab
2. Click "Generate Email Report"
3. Your email client opens with pre-filled report
4. Send to your accountability partner or career coach

**Export Report:**
1. Dashboard → Overview tab
2. Click "Export Report"
3. Downloads a .txt file with your weekly summary

## Settings

Access settings via the extension popup or dashboard sidebar.

**Available Settings:**
- Weekly application goal
- Daily reminders (toggle on/off)
- Weekly summary notifications
- Goal achievement celebrations
- Data export/import
- Reset all data

## Tips for Success

1. **Set Realistic Goals** - Start with 5-10 applications per week
2. **Update Daily** - Save applications as you apply
3. **Use Accountability** - Add a friend, mentor, or career coach
4. **Review Weekly** - Check your stats every Sunday
5. **Adjust Goals** - Increase as you build momentum

## Keyboard Shortcuts

- Open extension: Click icon or use Chrome's extension shortcut settings

## Privacy & Data

- All data stored locally in your browser
- No data sent to external servers
- Export your data anytime
- Delete all data anytime

## Troubleshooting

**Auto-fill not working?**
- Not all job sites are supported
- Manually enter details if auto-fill fails
- Common sites like LinkedIn, Indeed, Glassdoor work well

**Notifications not appearing?**
- Check Chrome notification permissions
- Enable in Settings if disabled
- Restart browser if needed

**Lost your data?**
- Use Settings → Export Data regularly to backup
- Import from backup if needed

## Browser Compatibility

- ✅ Chrome 88+
- ✅ **Microsoft Edge 88+** (works identically - see [Edge Installation](docs/EDGE_INSTALLATION.md))
- ✅ Brave
- ❌ Firefox (different manifest version)
- ❌ Safari (different extension system)

## Monetization Ideas

This extension can be offered:

1. **Free with Donations** - "Buy me a coffee" button
2. **Freemium Model** - Basic free, Premium ($3-5/month) for:
   - Unlimited accountability partners (free: 2 max)
   - Advanced analytics and charts
   - Custom goal templates
   - Interview tracking
   - Automated follow-up reminders
3. **One-time Payment** - $9.99 lifetime access
4. **Pay-what-you-want** - Suggested $5, minimum $0

## Feedback & Support

Found a bug? Have a feature request? Please let us know!

## Version History

**v1.0.0** - Initial release
- Basic job tracking
- Weekly goals
- Accountability partners
- Email reports
- Dashboard with stats

## License

MIT License - Free to use and modify

---

Made with ❤️ for job seekers everywhere. Good luck with your search!

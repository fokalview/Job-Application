# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-04-18

### Added
- **Inline editing** - Click any field (job title, company, location) to edit directly in the table
- **Status dropdown** - Change application status with easy dropdown menu
- **Delete button** - Remove applications with trash icon
- Auto-save on all edits
- Microsoft Edge installation guide

### Changed
- Applications table now includes Actions column
- Status is now editable dropdown instead of static badge
- Improved table layout and responsiveness

---

## [1.0.0] - 2026-04-18

### Added
- Initial release of Job Application Tracker extension
- One-click job saving from any website
- Auto-detection of job title, company, location, and salary
- Weekly application goal setting
- Progress tracking with visual progress bars
- Dashboard with statistics (total apps, weekly count, weeks on track, average)
- Accountability partner system
- Email report generation
- Weekly summary notifications
- Daily reminder notifications
- Goal achievement celebrations
- Data export/import functionality
- Settings page for customization
- Support for 50+ job boards including LinkedIn, Indeed, Glassdoor, Handshake
- Local data storage (privacy-first, no external servers)
- Badge counter showing weekly progress
- Status tracking (Applied, Interviewing, Offer, Rejected)

### Features
- **Popup Interface**: Quick-save form with auto-fill
- **Dashboard**: Overview, Applications list, Accountability tab
- **Notifications**: Smart reminders based on progress
- **Reports**: Professional email-ready weekly summaries
- **Settings**: Customizable goals and notification preferences

---

## [Unreleased]

### Planned Features
- Notes field per application
- Interview date tracking
- Follow-up reminders
- Application deadline tracking
- Tags and categories
- Search functionality
- Resume version tracking
- Charts and visualizations
- Dark mode
- Browser sync across devices

---

## Version History

- **v1.1.0** (2026-04-18) - Added inline editing and Edge support
- **v1.0.0** (2026-04-18) - Initial release

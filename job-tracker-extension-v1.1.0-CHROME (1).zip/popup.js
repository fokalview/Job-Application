// Initialize popup
document.addEventListener('DOMContentLoaded', async () => {
  // Check if this is first launch
  const result = await chrome.storage.local.get(['weeklyGoal', 'applications', 'setupComplete']);
  
  if (!result.setupComplete) {
    showWelcomeScreen();
  } else {
    showQuickSave();
    loadProgress();
    autoFillFromPage();
  }

  // Event listeners
  document.getElementById('startBtn')?.addEventListener('click', completeSetup);
  document.getElementById('saveBtn')?.addEventListener('click', saveApplication);
  document.getElementById('dashboardBtn')?.addEventListener('click', openDashboard);
  document.getElementById('settingsBtn')?.addEventListener('click', openSettings);
});

// Show welcome screen for first-time users
function showWelcomeScreen() {
  document.getElementById('welcomeScreen').style.display = 'block';
  document.getElementById('quickSaveForm').style.display = 'none';
}

// Show quick save form
function showQuickSave() {
  document.getElementById('welcomeScreen').style.display = 'none';
  document.getElementById('quickSaveForm').style.display = 'block';
}

// Complete initial setup
async function completeSetup() {
  const weeklyGoal = parseInt(document.getElementById('weeklyGoalInput').value);
  
  await chrome.storage.local.set({
    weeklyGoal,
    setupComplete: true,
    applications: [],
    accountabilityPartners: []
  });

  showQuickSave();
  loadProgress();
  autoFillFromPage();
}

// Load weekly progress
async function loadProgress() {
  const result = await chrome.storage.local.get(['applications', 'weeklyGoal']);
  const applications = result.applications || [];
  const weeklyGoal = result.weeklyGoal || 10;

  // Get start of current week (Sunday)
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  // Count applications this week
  const weeklyCount = applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= startOfWeek;
  }).length;

  // Update UI
  document.getElementById('weeklyCount').textContent = weeklyCount;
  document.getElementById('weeklyGoal').textContent = weeklyGoal;
  
  const progressPercent = Math.min((weeklyCount / weeklyGoal) * 100, 100);
  document.getElementById('progressFill').style.width = `${progressPercent}%`;

  // Update badge
  chrome.action.setBadgeText({ text: weeklyCount.toString() });
  chrome.action.setBadgeBackgroundColor({ color: weeklyCount >= weeklyGoal ? '#10b981' : '#0066cc' });
}

// Auto-fill job details from current page
async function autoFillFromPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  // Set URL
  document.getElementById('url').value = tab.url;

  // Try to extract job details from page
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: extractJobDetails
    });

    if (results && results[0] && results[0].result) {
      const details = results[0].result;
      if (details.title) document.getElementById('jobTitle').value = details.title;
      if (details.company) document.getElementById('company').value = details.company;
      if (details.location) document.getElementById('location').value = details.location;
      if (details.salary) document.getElementById('salary').value = details.salary;
    }
  } catch (error) {
    console.log('Could not extract job details:', error);
  }
}

// Function to inject into page to extract job details
function extractJobDetails() {
  const details = {
    title: '',
    company: '',
    location: '',
    salary: ''
  };

  // Common selectors for job boards
  const titleSelectors = [
    'h1',
    '[class*="job-title"]',
    '[class*="jobTitle"]',
    '[data-testid*="title"]',
    '.job-header h1',
    '[class*="posting-headline"]'
  ];

  const companySelectors = [
    '[class*="company"]',
    '[class*="employer"]',
    '[data-company]',
    'a[href*="/company/"]',
    '[class*="topcard__org-name"]'
  ];

  const locationSelectors = [
    '[class*="location"]',
    '[class*="job-location"]',
    '[data-testid*="location"]'
  ];

  const salarySelectors = [
    '[class*="salary"]',
    '[class*="compensation"]',
    '[class*="pay"]'
  ];

  // Extract title
  for (const selector of titleSelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim()) {
      details.title = elem.textContent.trim();
      break;
    }
  }

  // Extract company
  for (const selector of companySelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim()) {
      details.company = elem.textContent.trim();
      break;
    }
  }

  // Extract location
  for (const selector of locationSelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim()) {
      details.location = elem.textContent.trim();
      break;
    }
  }

  // Extract salary
  for (const selector of salarySelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim() && elem.textContent.match(/\$|USD|salary/i)) {
      details.salary = elem.textContent.trim();
      break;
    }
  }

  return details;
}

// Save application
async function saveApplication() {
  const jobTitle = document.getElementById('jobTitle').value.trim();
  const company = document.getElementById('company').value.trim();
  const location = document.getElementById('location').value.trim();
  const salary = document.getElementById('salary').value.trim();
  const url = document.getElementById('url').value.trim();

  if (!jobTitle || !company) {
    alert('Please fill in at least Job Title and Company');
    return;
  }

  const application = {
    id: Date.now().toString(),
    jobTitle,
    company,
    location,
    salary,
    url,
    dateApplied: new Date().toISOString(),
    status: 'applied',
    notes: ''
  };

  // Save to storage
  const result = await chrome.storage.local.get(['applications']);
  const applications = result.applications || [];
  applications.push(application);
  await chrome.storage.local.set({ applications });

  // Show confirmation
  const saveBtn = document.getElementById('saveBtn');
  const confirmation = document.getElementById('savedConfirmation');
  
  saveBtn.style.display = 'none';
  confirmation.style.display = 'block';

  // Reload progress
  await loadProgress();

  // Check if user hit their goal
  checkGoalMilestone(applications);

  // Reset form after 1.5 seconds
  setTimeout(() => {
    document.getElementById('jobTitle').value = '';
    document.getElementById('company').value = '';
    document.getElementById('location').value = '';
    document.getElementById('salary').value = '';
    
    confirmation.style.display = 'none';
    saveBtn.style.display = 'flex';
    
    autoFillFromPage();
  }, 1500);

  // Send notification to background for accountability
  chrome.runtime.sendMessage({ 
    action: 'applicationAdded',
    application 
  });
}

// Check if user hit a milestone
async function checkGoalMilestone(applications) {
  const result = await chrome.storage.local.get(['weeklyGoal']);
  const weeklyGoal = result.weeklyGoal || 10;

  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  const weeklyCount = applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= startOfWeek;
  }).length;

  if (weeklyCount === weeklyGoal) {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '🎉 Weekly Goal Achieved!',
      message: `Great work! You've hit your goal of ${weeklyGoal} applications this week.`
    });
  }
}

// Open dashboard
function openDashboard() {
  chrome.tabs.create({ url: 'dashboard.html' });
}

// Open settings
function openSettings() {
  chrome.tabs.create({ url: 'settings.html' });
}

// Background service worker for notifications and reminders

// Set up alarms when extension is installed
chrome.runtime.onInstalled.addListener(() => {
  // Daily reminder at 6 PM
  chrome.alarms.create('dailyReminder', {
    when: getNextReminderTime(18, 0), // 6 PM
    periodInMinutes: 24 * 60 // Daily
  });

  // Weekly summary on Sunday at 5 PM
  chrome.alarms.create('weeklySummary', {
    when: getNextSundayTime(17, 0), // Sunday 5 PM
    periodInMinutes: 7 * 24 * 60 // Weekly
  });
});

// Handle alarms
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'dailyReminder') {
    await sendDailyReminder();
  } else if (alarm.name === 'weeklySummary') {
    await sendWeeklySummary();
  }
});

// Handle messages from popup/dashboard
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'applicationAdded') {
    handleApplicationAdded(message.application);
  }
  return true;
});

// Send daily reminder
async function sendDailyReminder() {
  const result = await chrome.storage.local.get(['applications', 'weeklyGoal', 'setupComplete']);
  
  if (!result.setupComplete) return;

  const applications = result.applications || [];
  const weeklyGoal = result.weeklyGoal || 10;

  // Get applications this week
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  const weeklyCount = applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= startOfWeek;
  }).length;

  const remaining = weeklyGoal - weeklyCount;

  // Don't send notification if goal is already met
  if (remaining <= 0) return;

  // Send reminder notification
  let message = '';
  if (remaining === 1) {
    message = '1 more application to reach your weekly goal! 💪';
  } else if (remaining <= 3) {
    message = `${remaining} applications left to hit your goal this week!`;
  } else {
    message = `You're ${remaining} applications away from your goal. Keep going!`;
  }

  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Job Search Reminder',
    message: message,
    priority: 1
  });
}

// Send weekly summary
async function sendWeeklySummary() {
  const result = await chrome.storage.local.get(['applications', 'weeklyGoal', 'setupComplete']);
  
  if (!result.setupComplete) return;

  const applications = result.applications || [];
  const weeklyGoal = result.weeklyGoal || 10;

  // Get last week's applications
  const now = new Date();
  const lastWeekStart = new Date(now);
  lastWeekStart.setDate(now.getDate() - now.getDay() - 7);
  lastWeekStart.setHours(0, 0, 0, 0);
  
  const lastWeekEnd = new Date(lastWeekStart);
  lastWeekEnd.setDate(lastWeekStart.getDate() + 7);

  const lastWeekCount = applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= lastWeekStart && appDate < lastWeekEnd;
  }).length;

  let title = '';
  let message = '';

  if (lastWeekCount >= weeklyGoal) {
    title = '🎉 Great Week!';
    message = `You applied to ${lastWeekCount} jobs last week and hit your goal!`;
  } else if (lastWeekCount > 0) {
    title = '📊 Weekly Summary';
    message = `You applied to ${lastWeekCount} jobs last week. Goal was ${weeklyGoal}.`;
  } else {
    title = '💼 New Week Ahead';
    message = `Let's make this week count! Your goal: ${weeklyGoal} applications.`;
  }

  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: title,
    message: message,
    priority: 2
  });
}

// Handle application added
function handleApplicationAdded(application) {
  // Could send notification to accountability partners here
  // For now, just log it
  console.log('Application added:', application);
}

// Get next reminder time
function getNextReminderTime(hour, minute) {
  const now = new Date();
  const reminder = new Date();
  reminder.setHours(hour, minute, 0, 0);
  
  if (reminder <= now) {
    reminder.setDate(reminder.getDate() + 1);
  }
  
  return reminder.getTime();
}

// Get next Sunday time
function getNextSundayTime(hour, minute) {
  const now = new Date();
  const sunday = new Date();
  sunday.setHours(hour, minute, 0, 0);
  
  const daysUntilSunday = (7 - now.getDay()) % 7;
  sunday.setDate(now.getDate() + (daysUntilSunday || 7));
  
  if (sunday <= now) {
    sunday.setDate(sunday.getDate() + 7);
  }
  
  return sunday.getTime();
}

// Update badge on storage change
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (changes.applications) {
    updateBadge();
  }
});

// Update badge
async function updateBadge() {
  const result = await chrome.storage.local.get(['applications', 'weeklyGoal']);
  const applications = result.applications || [];
  const weeklyGoal = result.weeklyGoal || 10;

  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  const weeklyCount = applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= startOfWeek;
  }).length;

  chrome.action.setBadgeText({ text: weeklyCount.toString() });
  chrome.action.setBadgeBackgroundColor({ 
    color: weeklyCount >= weeklyGoal ? '#10b981' : '#0066cc' 
  });
}

// Initialize badge on startup
updateBadge();

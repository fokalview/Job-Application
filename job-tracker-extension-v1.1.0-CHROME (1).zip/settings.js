// Settings page functionality

document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  setupEventListeners();
});

// Load current settings
async function loadSettings() {
  const result = await chrome.storage.local.get([
    'weeklyGoal',
    'dailyReminders',
    'weeklySummary',
    'goalNotifications'
  ]);

  document.getElementById('weeklyGoalSetting').value = result.weeklyGoal || 10;
  document.getElementById('dailyReminders').checked = result.dailyReminders !== false;
  document.getElementById('weeklySummary').checked = result.weeklySummary !== false;
  document.getElementById('goalNotifications').checked = result.goalNotifications !== false;
}

// Setup event listeners
function setupEventListeners() {
  document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);
  document.getElementById('exportDataBtn').addEventListener('click', exportData);
  document.getElementById('importDataBtn').addEventListener('click', () => {
    document.getElementById('importFileInput').click();
  });
  document.getElementById('importFileInput').addEventListener('change', importData);
  document.getElementById('resetDataBtn').addEventListener('click', resetData);
}

// Save settings
async function saveSettings() {
  const weeklyGoal = parseInt(document.getElementById('weeklyGoalSetting').value);
  const dailyReminders = document.getElementById('dailyReminders').checked;
  const weeklySummary = document.getElementById('weeklySummary').checked;
  const goalNotifications = document.getElementById('goalNotifications').checked;

  await chrome.storage.local.set({
    weeklyGoal,
    dailyReminders,
    weeklySummary,
    goalNotifications
  });

  // Show success message
  const btn = document.getElementById('saveSettingsBtn');
  const originalText = btn.innerHTML;
  
  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M3 8l3 3 7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
    Settings Saved!
  `;
  btn.style.background = '#10b981';

  setTimeout(() => {
    btn.innerHTML = originalText;
    btn.style.background = '';
  }, 2000);
}

// Export data
async function exportData() {
  const data = await chrome.storage.local.get(null);
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `job-tracker-backup-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// Import data
async function importData(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (e) => {
    try {
      const data = JSON.parse(e.target.result);
      
      if (!confirm('This will replace all your current data. Are you sure?')) {
        return;
      }

      await chrome.storage.local.clear();
      await chrome.storage.local.set(data);
      
      alert('Data imported successfully! The page will now reload.');
      window.location.reload();
    } catch (error) {
      alert('Error importing data. Please make sure the file is valid.');
      console.error('Import error:', error);
    }
  };
  reader.readAsText(file);
  
  // Reset file input
  event.target.value = '';
}

// Reset data
async function resetData() {
  const confirmation = prompt(
    'This will permanently delete ALL your data. Type "DELETE" to confirm:'
  );

  if (confirmation !== 'DELETE') {
    alert('Reset cancelled.');
    return;
  }

  await chrome.storage.local.clear();
  
  alert('All data has been deleted. The page will now reload.');
  window.location.reload();
}

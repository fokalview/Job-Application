// Current view state
let currentView = 'overview';
let applications = [];
let accountabilityPartners = [];
let weeklyGoal = 10;

// Initialize dashboard
document.addEventListener('DOMContentLoaded', async () => {
  await loadData();
  setupEventListeners();
  renderCurrentView();
});

// Load all data from storage
async function loadData() {
  const result = await chrome.storage.local.get(['applications', 'accountabilityPartners', 'weeklyGoal']);
  applications = result.applications || [];
  accountabilityPartners = result.accountabilityPartners || [];
  weeklyGoal = result.weeklyGoal || 10;
}

// Setup event listeners
function setupEventListeners() {
  // Navigation
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      if (!e.currentTarget.hasAttribute('href') || e.currentTarget.getAttribute('href') === '#') {
        e.preventDefault();
        const view = e.currentTarget.dataset.view;
        if (view) {
          switchView(view);
        }
      }
    });
  });

  // Export button
  document.getElementById('exportBtn')?.addEventListener('click', exportReport);

  // Filter
  document.getElementById('statusFilter')?.addEventListener('change', filterApplications);

  // Add partner button
  document.getElementById('addPartnerBtn')?.addEventListener('click', openAddPartnerModal);
  document.getElementById('closeModalBtn')?.addEventListener('click', closeAddPartnerModal);
  document.getElementById('cancelPartnerBtn')?.addEventListener('click', closeAddPartnerModal);
  document.getElementById('savePartnerBtn')?.addEventListener('click', savePartner);

  // Generate report button
  document.getElementById('generateReportBtn')?.addEventListener('click', generateEmailReport);
}

// Switch between views
function switchView(view) {
  currentView = view;
  
  // Update navigation
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.dataset.view === view) {
      item.classList.add('active');
    }
  });

  // Hide all views
  document.querySelectorAll('.view').forEach(v => v.style.display = 'none');
  
  // Show current view
  const viewElement = document.getElementById(`${view}View`);
  if (viewElement) {
    viewElement.style.display = 'block';
  }

  renderCurrentView();
}

// Render current view
function renderCurrentView() {
  updateSidebarProgress();
  
  switch (currentView) {
    case 'overview':
      renderOverview();
      break;
    case 'applications':
      renderApplicationsTable();
      break;
    case 'accountability':
      renderAccountability();
      break;
  }
}

// Update sidebar progress
function updateSidebarProgress() {
  const weeklyCount = getWeeklyApplicationCount();
  
  document.getElementById('sidebarWeeklyCount').textContent = weeklyCount;
  document.getElementById('sidebarWeeklyGoal').textContent = weeklyGoal;
  
  const progressPercent = Math.min((weeklyCount / weeklyGoal) * 100, 100);
  document.getElementById('sidebarProgressFill').style.width = `${progressPercent}%`;
}

// Get weekly application count
function getWeeklyApplicationCount() {
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  return applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= startOfWeek;
  }).length;
}

// Render overview
function renderOverview() {
  // Stats
  const totalApps = applications.length;
  const weeklyCount = getWeeklyApplicationCount();
  const weeksOnTrack = calculateWeeksOnTrack();
  const avgPerWeek = calculateAvgPerWeek();

  document.getElementById('totalApplications').textContent = totalApps;
  document.getElementById('weekApplications').textContent = weeklyCount;
  document.getElementById('weeksOnTrack').textContent = weeksOnTrack;
  document.getElementById('avgPerWeek').textContent = avgPerWeek.toFixed(1);

  // Progress
  document.getElementById('currentWeekCount').textContent = weeklyCount;
  document.getElementById('currentWeekGoal').textContent = weeklyGoal;
  
  const progressPercent = Math.min((weeklyCount / weeklyGoal) * 100, 100);
  document.getElementById('mainProgressFill').style.width = `${progressPercent}%`;
  document.getElementById('progressPercentage').textContent = `${Math.round(progressPercent)}%`;

  // Progress message
  const remaining = weeklyGoal - weeklyCount;
  let message = '';
  if (weeklyCount >= weeklyGoal) {
    message = '🎉 Awesome! You\'ve hit your weekly goal!';
  } else if (remaining === 1) {
    message = `Just 1 more application to reach your goal!`;
  } else if (remaining <= 3) {
    message = `${remaining} more applications to hit your goal. You've got this!`;
  } else {
    message = `Keep going! ${remaining} applications to reach your weekly goal.`;
  }
  document.getElementById('progressMessage').textContent = message;

  // Recent applications
  renderRecentApplications();
}

// Calculate weeks on track
function calculateWeeksOnTrack() {
  if (applications.length === 0) return 0;

  const weekCounts = {};
  
  applications.forEach(app => {
    const date = new Date(app.dateApplied);
    const weekKey = getWeekKey(date);
    weekCounts[weekKey] = (weekCounts[weekKey] || 0) + 1;
  });

  let onTrack = 0;
  for (const count of Object.values(weekCounts)) {
    if (count >= weeklyGoal) onTrack++;
  }

  return onTrack;
}

// Calculate average per week
function calculateAvgPerWeek() {
  if (applications.length === 0) return 0;

  const oldestApp = applications.reduce((oldest, app) => {
    const appDate = new Date(app.dateApplied);
    return appDate < oldest ? appDate : oldest;
  }, new Date());

  const now = new Date();
  const weeksDiff = Math.max(1, Math.ceil((now - oldestApp) / (7 * 24 * 60 * 60 * 1000)));

  return applications.length / weeksDiff;
}

// Get week key for grouping
function getWeekKey(date) {
  const startOfWeek = new Date(date);
  startOfWeek.setDate(date.getDate() - date.getDay());
  startOfWeek.setHours(0, 0, 0, 0);
  return startOfWeek.toISOString();
}

// Render recent applications
function renderRecentApplications() {
  const container = document.getElementById('recentApplicationsList');
  const recent = applications.slice(-5).reverse();

  if (recent.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
          <circle cx="24" cy="24" r="20" stroke="#d1d5db" stroke-width="2"/>
          <path d="M24 16v16M16 24h16" stroke="#d1d5db" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <p>No applications yet</p>
        <small>Click the extension icon on any job posting to save it</small>
      </div>
    `;
    return;
  }

  container.innerHTML = recent.map(app => `
    <div class="application-item">
      <div class="application-info">
        <h4>${app.jobTitle}</h4>
        <div class="application-meta">
          <span>🏢 ${app.company}</span>
          ${app.location ? `<span>📍 ${app.location}</span>` : ''}
          <span>📅 ${formatDate(app.dateApplied)}</span>
        </div>
      </div>
      <div class="application-actions">
        ${app.url ? `<a href="${app.url}" target="_blank" class="btn-icon" title="View job">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M10 3v14M3 10h14" stroke="currentColor" stroke-width="1.5"/>
          </svg>
        </a>` : ''}
      </div>
    </div>
  `).join('');
}

// Render applications table
function renderApplicationsTable() {
  const container = document.getElementById('applicationsTable');
  
  if (applications.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
          <circle cx="24" cy="24" r="20" stroke="#d1d5db" stroke-width="2"/>
          <path d="M24 16v16M16 24h16" stroke="#d1d5db" stroke-width="2" stroke-linecap="round"/>
        </svg>
        <p>No applications yet</p>
        <small>Click the extension icon on any job posting to save it</small>
      </div>
    `;
    return;
  }

  const filterValue = document.getElementById('statusFilter')?.value || 'all';
  const filtered = filterValue === 'all' 
    ? applications 
    : applications.filter(app => app.status === filterValue);

  container.innerHTML = `
    <div class="table-header">
      <div>Job Title</div>
      <div>Company</div>
      <div>Location</div>
      <div>Date Applied</div>
      <div>Status</div>
      <div>Actions</div>
    </div>
    ${filtered.map(app => `
      <div class="table-row" data-id="${app.id}">
        <div class="table-cell job-title editable" data-field="jobTitle">${app.jobTitle}</div>
        <div class="table-cell editable" data-field="company">${app.company}</div>
        <div class="table-cell editable" data-field="location">${app.location || '—'}</div>
        <div class="table-cell">${formatDate(app.dateApplied)}</div>
        <div class="table-cell">
          <select class="status-select" data-id="${app.id}" onchange="updateStatus('${app.id}', this.value)">
            <option value="applied" ${app.status === 'applied' ? 'selected' : ''}>Applied</option>
            <option value="interviewing" ${app.status === 'interviewing' ? 'selected' : ''}>Interviewing</option>
            <option value="offer" ${app.status === 'offer' ? 'selected' : ''}>Offer</option>
            <option value="rejected" ${app.status === 'rejected' ? 'selected' : ''}>Rejected</option>
          </select>
        </div>
        <div class="table-cell" style="display: flex; gap: 4px;">
          ${app.url ? `<a href="${app.url}" target="_blank" class="btn-icon" title="View job">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M6 3h7v7M13 3L3 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
          </a>` : ''}
          <button class="btn-icon" onclick="deleteApplication('${app.id}')" title="Delete">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M4 6h8M6 6V4h4v2M5 6v7h6V6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
          </button>
        </div>
      </div>
    `).join('')}
  `;

  // Add click handlers for inline editing
  document.querySelectorAll('.editable').forEach(cell => {
    cell.addEventListener('click', makeEditable);
  });
}

// Make cell editable inline
function makeEditable(e) {
  const cell = e.target;
  if (cell.querySelector('input')) return; // Already editing

  const currentValue = cell.textContent;
  const field = cell.dataset.field;
  const row = cell.closest('.table-row');
  const appId = row.dataset.id;

  const input = document.createElement('input');
  input.type = 'text';
  input.value = currentValue === '—' ? '' : currentValue;
  input.style.width = '100%';
  input.style.padding = '4px 8px';
  input.style.border = '1px solid #0066cc';
  input.style.borderRadius = '4px';
  input.style.fontSize = '14px';

  cell.textContent = '';
  cell.appendChild(input);
  input.focus();
  input.select();

  const saveEdit = async () => {
    const newValue = input.value.trim();
    const app = applications.find(a => a.id === appId);
    
    if (app) {
      app[field] = newValue;
      await chrome.storage.local.set({ applications });
      renderApplicationsTable();
    }
  };

  input.addEventListener('blur', saveEdit);
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') saveEdit();
  });
}

// Update application status
async function updateStatus(appId, newStatus) {
  const app = applications.find(a => a.id === appId);
  if (app) {
    app.status = newStatus;
    await chrome.storage.local.set({ applications });
    renderApplicationsTable();
  }
}

// Delete application
async function deleteApplication(appId) {
  if (!confirm('Delete this application?')) return;

  applications = applications.filter(a => a.id !== appId);
  await chrome.storage.local.set({ applications });
  await loadData();
  renderCurrentView();
}

// Filter applications
function filterApplications() {
  renderApplicationsTable();
}

// Render accountability view
function renderAccountability() {
  renderPartnersList();
}

// Render partners list
function renderPartnersList() {
  const container = document.getElementById('partnersList');
  
  if (accountabilityPartners.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
          <circle cx="24" cy="20" r="6" stroke="#d1d5db" stroke-width="2"/>
          <path d="M12 36c0-6.6 5.4-12 12-12s12 5.4 12 12" stroke="#d1d5db" stroke-width="2"/>
        </svg>
        <p>No accountability partners yet</p>
        <small>Add someone to share your progress with</small>
      </div>
    `;
    return;
  }

  container.innerHTML = accountabilityPartners.map(partner => `
    <div class="partner-item">
      <div class="partner-info">
        <h4>${partner.name}</h4>
        <p>${partner.email} • Updates ${partner.frequency}</p>
      </div>
      <button class="btn-icon" onclick="removePartner('${partner.id}')" title="Remove">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
          <path d="M5 5l10 10M15 5L5 15" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
        </svg>
      </button>
    </div>
  `).join('');
}

// Modal functions
function openAddPartnerModal() {
  document.getElementById('addPartnerModal').style.display = 'flex';
}

function closeAddPartnerModal() {
  document.getElementById('addPartnerModal').style.display = 'none';
  document.getElementById('partnerName').value = '';
  document.getElementById('partnerEmail').value = '';
  document.getElementById('shareFrequency').value = 'weekly';
}

async function savePartner() {
  const name = document.getElementById('partnerName').value.trim();
  const email = document.getElementById('partnerEmail').value.trim();
  const frequency = document.getElementById('shareFrequency').value;

  if (!name || !email) {
    alert('Please fill in all fields');
    return;
  }

  const partner = {
    id: Date.now().toString(),
    name,
    email,
    frequency,
    addedDate: new Date().toISOString()
  };

  accountabilityPartners.push(partner);
  await chrome.storage.local.set({ accountabilityPartners });

  closeAddPartnerModal();
  renderPartnersList();
}

async function removePartner(id) {
  if (!confirm('Remove this accountability partner?')) return;

  accountabilityPartners = accountabilityPartners.filter(p => p.id !== id);
  await chrome.storage.local.set({ accountabilityPartners });
  renderPartnersList();
}

// Export report
function exportReport() {
  const report = generateReportText();
  const blob = new Blob([report], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `job-search-report-${formatDateFile(new Date())}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

// Generate email report
function generateEmailReport() {
  const report = generateReportText();
  const subject = `Job Search Update - Week of ${formatDate(new Date())}`;
  const mailtoLink = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(report)}`;
  window.location.href = mailtoLink;
}

// Generate report text
function generateReportText() {
  const weeklyCount = getWeeklyApplicationCount();
  const totalApps = applications.length;
  
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  
  const thisWeek = applications.filter(app => {
    const appDate = new Date(app.dateApplied);
    return appDate >= startOfWeek;
  });

  return `JOB SEARCH WEEKLY REPORT
${formatDate(startOfWeek)} - ${formatDate(now)}

SUMMARY
-------
Applications this week: ${weeklyCount} / ${weeklyGoal}
Total applications: ${totalApps}
Average per week: ${calculateAvgPerWeek().toFixed(1)}
Weeks on track: ${calculateWeeksOnTrack()}

THIS WEEK'S APPLICATIONS
------------------------
${thisWeek.length > 0 ? thisWeek.map(app => 
  `• ${app.jobTitle} at ${app.company}${app.location ? ` (${app.location})` : ''}
  Applied: ${formatDate(app.dateApplied)}
  ${app.url ? `Link: ${app.url}` : ''}`
).join('\n\n') : 'No applications this week'}

NEXT STEPS
----------
${weeklyCount >= weeklyGoal 
  ? '✓ Weekly goal achieved! Keep up the momentum.'
  : `□ ${weeklyGoal - weeklyCount} more applications needed to reach weekly goal`}

---
Generated by Job Tracker Extension
`;
}

// Format date
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric',
    year: 'numeric'
  });
}

// Format date for filename
function formatDateFile(date) {
  return date.toISOString().split('T')[0];
}

// Make removePartner globally accessible
window.removePartner = removePartner;
window.updateStatus = updateStatus;
window.deleteApplication = deleteApplication;

// Content script - runs on all pages
// Minimal script - main extraction happens in popup.js

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractJobDetails') {
    const details = extractJobDetails();
    sendResponse(details);
  }
  return true;
});

// This is also defined in popup.js for injection, but kept here for consistency
function extractJobDetails() {
  const details = {
    title: '',
    company: '',
    location: '',
    salary: ''
  };

  // Common selectors for job boards
  const titleSelectors = [
    'h1',
    '[class*="job-title"]',
    '[class*="jobTitle"]',
    '[data-testid*="title"]',
    '.job-header h1',
    '[class*="posting-headline"]'
  ];

  const companySelectors = [
    '[class*="company"]',
    '[class*="employer"]',
    '[data-company]',
    'a[href*="/company/"]',
    '[class*="topcard__org-name"]'
  ];

  const locationSelectors = [
    '[class*="location"]',
    '[class*="job-location"]',
    '[data-testid*="location"]'
  ];

  const salarySelectors = [
    '[class*="salary"]',
    '[class*="compensation"]',
    '[class*="pay"]'
  ];

  // Extract title
  for (const selector of titleSelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim()) {
      details.title = elem.textContent.trim();
      break;
    }
  }

  // Extract company
  for (const selector of companySelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim()) {
      details.company = elem.textContent.trim();
      break;
    }
  }

  // Extract location
  for (const selector of locationSelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim()) {
      details.location = elem.textContent.trim();
      break;
    }
  }

  // Extract salary
  for (const selector of salarySelectors) {
    const elem = document.querySelector(selector);
    if (elem && elem.textContent.trim() && elem.textContent.match(/\$|USD|salary/i)) {
      details.salary = elem.textContent.trim();
      break;
    }
  }

  return details;
}
